/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex4.photon.marual;

/**
 *
 * @author PHOTON
 */
public class Singer {
    private String name, favoriteSong;
    private int noOfPerformances;
    private double earnings;
    private static int totalPerformances = 0;
    
    public Singer(String n, int p, double e, String s){
        this.name = n;
        this.noOfPerformances = p;
        this.earnings = e;
        this.favoriteSong = s;
        totalPerformances += this.noOfPerformances;
    }    
    public void performForAudience(int p){
        System.out.printf("%s sang for %d people.", this.name, p);
        this.noOfPerformances++;
        this.earnings += 100*p;
    }
    
    public void performForAudience(Singer n, int p){
        this.noOfPerformances++;
        n.addPerformanceValue(1);
        int profit = (100*p)/2;
        this.earnings += profit;
        n.addEarnings(profit);
        System.out.printf("%s and %s collaborated and sang for %d people.%n", this.name, n.getSingerName(), p);
    }
    
    public void changeFavSong(String m){
        this.favoriteSong = m;
    }
    
    public void addPerformanceValue(int p){
        this.noOfPerformances += p;
    }
    
    public void addEarnings(int e){
        this.earnings += e;
    }
    
    public String getSingerName(){
        return name;
    }
    
    public String getSingerFavSong(){
        return favoriteSong;
    }
    
    public int getPerformances(){
        return noOfPerformances;
    }
    
    public double getEarnings(){
        return earnings;
    }
    
    public static int getTotalPerformances(){
        return totalPerformances;
    }
}
