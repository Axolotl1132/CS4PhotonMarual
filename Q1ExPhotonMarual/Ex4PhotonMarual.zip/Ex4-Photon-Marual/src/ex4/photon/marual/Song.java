/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex4.photon.marual;

/**
 *
 * @author PHOTON
 */
public class Song {
    private String name;
    private int duration, yearReleased;
    private String singer;
    
    public Song(String n, int d, int y, String s){
        name = n;
        duration = d;
        yearReleased = y;
        singer = s;
    }
    
    public String getSongName(){
        return name;
    }
    
    public String getSinger(){
        return singer;
    }
    
    public int getDuration(){
        return duration;
    }
    
    public int getYear(){
        return yearReleased;
    }
}
