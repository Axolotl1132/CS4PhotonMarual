/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex4.photon.marual;

/**
 *
 * @author PHOTON
 */
public class Student {
    private String name, favSong;
    private int age;
    private double grade;
    
    public Student(String n, int a, String s, double g){
        name = n;
        age = a;
        favSong = s;
        grade = g;
    }
    
    public String getStudentName(){
        return name;
    }
    
    public String getStudentFavSong(){
        return favSong;
    }
    
    public int getAge(){
        return age;
    }
    
    public double getGrade(){
        return grade;
    }
}
