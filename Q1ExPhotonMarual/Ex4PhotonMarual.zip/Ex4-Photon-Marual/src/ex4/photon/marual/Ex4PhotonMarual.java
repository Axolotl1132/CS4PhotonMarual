/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex4.photon.marual;

/**
 *
 * @author PHOTON
 */
public class Ex4PhotonMarual {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Student peter = new Student("Peter", 15, "Invisible String", 91.3);
        Student morre = new Student("Morre", 16, "Through the Fire and Flames", 89.7);
        Student joe = new Student("Joe", 16, "Kamippoi na", 90.1);
        
        Song TTFAF = new Song("Through the Fire and Flames", 300, 2005, "DragonForce");
        Song IS = new Song("Invisible String", 253, 2020, "Talyor Swift");

        Singer max = new Singer("Max", 5, 1100, "Treasure");
        Singer noir = new Singer("Noir", 2, 500, "Bohemian Rhapsody");
        System.out.println(max.getPerformances());
        System.out.println(max.getEarnings());
        System.out.println(noir.getPerformances());
        System.out.println(noir.getEarnings());
        System.out.println(Singer.getTotalPerformances());
        max.performForAudience(noir, 20);
    }
    
}