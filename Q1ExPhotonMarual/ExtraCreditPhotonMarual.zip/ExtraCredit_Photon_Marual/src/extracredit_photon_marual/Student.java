/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package extracredit_photon_marual;
import java.util.ArrayList;
/**
 *
 * @author acer
 */
public class Student {
    public double totalTime;
    private String name;
    private ArrayList<Assignment> assignments;
    
    public Student(String n){
        this.name = n;
        assignments = new ArrayList();
    }
    
    public String getName(){
        return this.name;
    }
    
    public void finishAssignment(Assignment a){
        this.assignments.remove(a);
    }
    
    public double getTimeNeeded(){
        for(Assignment a : assignments){
            totalTime += a.getTimeAlloted();
        }
        return totalTime;
    }
    
    public ArrayList<Assignment> getAssignments(){
        return assignments;
    }
}
