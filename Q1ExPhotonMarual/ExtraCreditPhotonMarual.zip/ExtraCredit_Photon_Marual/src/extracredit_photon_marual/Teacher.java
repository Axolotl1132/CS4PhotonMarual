/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package extracredit_photon_marual;
import java.util.ArrayList;
/**
 *
 * @author acer
 */
public class Teacher {
    private String name, subject;
    private ArrayList<Section> sections;
    
    public Teacher(String n, String s, Section sec){
        this.name = n;
        this.subject = s;
        sections = new ArrayList();
        sections.add(sec);
    }
    
    public Teacher(String n, String s, Section sec1, Section sec2){
        this.name = n;
        this.subject = s;
        sections = new ArrayList();
        sections.add(sec1);
        sections.add(sec2);
    }
    
    public String getName(){
        return this.name;
    }
    
    public String getSubject(){
        return this.subject;
    }
    
    public void giveAssignment(Assignment a){
        for(Section c : sections){
            for(Student s : c.getStudents()){
                s.getAssignments().add(a);
            }
        }
    }
}
