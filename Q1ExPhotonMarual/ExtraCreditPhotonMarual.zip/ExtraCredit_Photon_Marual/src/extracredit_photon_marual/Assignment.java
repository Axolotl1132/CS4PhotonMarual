/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package extracredit_photon_marual;
import java.util.ArrayList;
/**
 *
 * @author acer
 */
public class Assignment {
    private String name;
    private double timeAlloted;
    
    public Assignment(String n, double t){
        this.name = n;
        this.timeAlloted = t;
    }
    
    public String getName(){
        return name;
    }
    
    public double getTimeAlloted(){
        return timeAlloted;
    }
}

