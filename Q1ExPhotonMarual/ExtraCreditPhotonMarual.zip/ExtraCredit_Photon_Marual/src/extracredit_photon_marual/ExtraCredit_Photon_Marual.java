/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package extracredit_photon_marual;

/**
 *
 * @author acer
 */
public class ExtraCredit_Photon_Marual {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Assignment a1 = new Assignment("Quiz", 2);
        Assignment a2 = new Assignment("Seatwork", 3);
        Assignment a3 = new Assignment("Exam", 5);
        
        Student s1 = new Student("Cary");
        Student s2 = new Student("Hale");
        Student s3 = new Student("Sid");
        
        Section c1 = new Section("Photon");
        Section c2 = new Section("Adelfa");
        
        Teacher t1 = new Teacher("Mark", "Computer Science", c1, c2);
        Teacher t2 = new Teacher("Pun", "Mathematics", c2);
        Teacher t3 = new Teacher("Kat", "Chemistry", c1);
        
        c1.addStudent(s1);
        c1.addStudent(s2);
        c2.addStudent(s3);
        
        t1.giveAssignment(a1);
        t2.giveAssignment(a2);
        t3.giveAssignment(a3);
        s2.finishAssignment(a1);
        System.out.printf("%s remaining work: %.2f%n", s1.getName(), s1.getTimeNeeded());
        System.out.printf("%s remaining work: %.2f%n", s2.getName(), s2.getTimeNeeded());
        System.out.printf("%s remaining work: %.2f%n", s3.getName(), s3.getTimeNeeded());
    }
    
}
