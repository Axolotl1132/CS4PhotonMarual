/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package extracredit_photon_marual;
import java.util.ArrayList;
/**
 *
 * @author acer
 */
public class Section {
    private String name;
    private ArrayList<Student> students = new ArrayList();
    
    public Section(String n){
        this.name = n;
    }
    
    public String getName(){
        return name;
    }
    
    public void addStudent(Student s){
        students.add(s);
    }
    
    public ArrayList<Student> getStudents(){
        return students;
    }
}
