/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex3photonmarual;

/**
 *
 * @author Marual Family
 */
public class Singer {
    String name;
    int noOfPerformances;
    double earnings;
    String favoriteSong;
    
    public Singer(String n, int p, double e, String s){
        name = n;
        noOfPerformances = p;
        earnings = e;
        favoriteSong = s;
    }
    public void getDetails(){
        System.out.printf("Name: %s%n Number of Performances: %d%n Earnings: %.2f%n Favorite Song: %s%n%n",
                          this.name, this.noOfPerformances, this.earnings, this.favoriteSong);
    }
    public void performForAudience(int n){
        this.noOfPerformances++;
        this.earnings += 100*n;
    }
    
    public void changeFavSong(String m){
        favoriteSong = m;
    }
}
