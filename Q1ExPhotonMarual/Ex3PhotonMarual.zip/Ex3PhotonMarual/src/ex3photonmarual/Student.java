/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex3photonmarual;

/**
 *
 * @author Marual Family
 */
public class Student {
    String name;
    int age;
    String favSong;
    double grade;
    
    public Student(String n, int a, String s, double g){
        name = n;
        age = a;
        favSong = s;
        grade = g;
    }
    
    public void listParameters(){
        System.out.printf("Hi. My name is %s.%n I am %d years old.%n My favorite song is %s.%n My final grade is %.1f.%n%n", 
                           this.name, this.age, this.favSong, this.grade);
    }
}
