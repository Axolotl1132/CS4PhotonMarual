/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex3photonmarual;

/**
 *
 * @author Marual Family
 */
public class Ex3PhotonMarual {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Student peter = new Student("Peter", 15, "Invisible String", 91.3);
        peter.listParameters();
        
        Student morre = new Student("Morre", 16, "Through the Fire and Flames", 89.7);
        morre.listParameters();
        
        Student joe = new Student("Joe", 16, "Kamippoi na", 90.1);
        joe.listParameters();
        
        
        Song TTFAF = new Song("Through the Fire and Flames", 300, 2005, "DragonForce");
        TTFAF.showDetails();
        
        Song IS = new Song("Invisible String", 253, 2020, "Taylor Swift");
        IS.showDetails();
        
        
        Singer max = new Singer("Max", 5, 1100,"Treasure");
        max.getDetails();
        max.favoriteSong = "Grenade";
        max.performForAudience(12);
        max.getDetails();
    }
}
