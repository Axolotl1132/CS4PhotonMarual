/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex3photonmarual;

/**
 *
 * @author Marual Family
 */
public class Song {
    String name;
    int duration;
    int yearReleased;
    String singer;
    
    public Song(String n, int d, int y, String s){
        name = n;
        duration = d;
        yearReleased = y;
        singer = s;
    }
    
    public void showDetails() {
        System.out.printf("Song name: %s.%n Duration(sec): %d.%n Year Released: %d.%n Singer: %s.%n%n"
                          , this.name, this.duration, this.yearReleased, this.singer);
    }
}
