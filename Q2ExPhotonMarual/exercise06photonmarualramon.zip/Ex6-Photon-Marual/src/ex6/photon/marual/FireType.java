/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex6.photon.marual;

/**
 *
 * @author acer
 */
public class FireType extends Monster{
    
    public FireType(String n, int m, int base){
        super(n, "Fire", "Grass", "Water", m, base);
        this.atk *= 1.3;
        this.def *= 0.7;
    }
    
    @Override
    public void special(){
        this.atk += 2;
        this.hp -= this.maxHP*0.1;
        System.out.println(this.getName() + " did a pose.");
    }
}
