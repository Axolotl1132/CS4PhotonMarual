/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex6.photon.marual;
import java.util.Scanner;
/**
 *
 * @author acer
 */
public class Ex6PhotonMarual {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Monster m1 = new FireType("Charmander", 60, 12);
        Monster m2 = new GrassType("Bulbasaur", 70, 10);
        Monster m3 = new WaterType("Squirtle", 70, 10);
        String repeat = "";
        do{
        System.out.print("""
                         Which battle do you want to see?
                         -Fire vs Grass (1)
                         -Water vs Fire (2)
                         -Grass vs Water (3)
                         """);
        boolean loop = true;
        Scanner sc = new Scanner(System.in);
        String ans = sc.nextLine();
        outerloop:
        switch(ans){
            case "1"://fire vs. grass
                m1.resetHealth();
                m2.resetHealth();
                while(loop){
                    m1.attack(m2);
                    if(m2.getHP() == 0){
                        break outerloop;
                    }
                    m2.attack(m1);
                    if(m1.getHP() == 0){
                        break outerloop;
                    }
                }
                
            case "2":
                //fire vs water
                m1.resetHealth();
                m3.resetHealth();
                while(loop){
                    m3.attack(m1);
                    if(m1.getHP() == 0){
                        break outerloop;
                    }
                    m1.attack(m3);
                    if(m3.getHP() == 0){
                        break outerloop;
                    }
                }
                
            case "3":
                //grass vs. water
                m2.resetHealth();
                m3.resetHealth();
                while(loop){
                    m3.attack(m2);
                    if(m2.getHP() == 0){
                        break outerloop;
                    }
                    m2.attack(m3);
                    if(m3.getHP() == 0){
                        break outerloop;
                    }
                }
                
            default:
                break;
        }
        System.out.println("Would you like to continue? y/n");
        repeat = sc.nextLine();
        } while(repeat.equals("y"));
    }
}
