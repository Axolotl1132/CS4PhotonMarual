/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex6.photon.marual;

/**
 *
 * @author acer
 */
public class GrassType extends Monster{
    public GrassType(String n, int m, int base){
        super(n, "Grass", "Water", "Fire", m, base);
    }
    
    @Override
    public void rest(){
        this.hp += this.maxHP * 0.5;
        if(this.hp > this.maxHP) this.hp = this.maxHP;
        System.out.println(this.getName() + " rested. It's health is now " + this.hp + ".");
    }
    
    @Override
    public void special(){
        this.hp += this.maxHP * 0.2;
        if(this.hp > this.maxHP) this.hp = this.maxHP;
        System.out.println(this.getName() + " did a pose.");
    }
}
