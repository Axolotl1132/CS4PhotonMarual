/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex7.photon.marual;
/**
 *
 * @author acer
 */
public class Ex7PhotonMarual {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Trainer t1 = new Trainer("Ash");
        NPC n1 = new NPC("Garn", "Good Luck!");
        Monster m1 = new FireType("Charmander", 6, 26);
        Location l1 = new Location("Pisay", "Food");
        
        t1.inspect(n1);
        t1.inspect(m1);
        t1.inspect(l1);
    }
}

